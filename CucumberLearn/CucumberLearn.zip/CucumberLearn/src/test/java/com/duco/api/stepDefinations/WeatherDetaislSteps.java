package com.duco.api.stepDefinations;



import java.util.HashMap;


import com.duco.api.pageobjects.BasePage;
import org.apache.log4j.Logger;

import com.duco.api.service.WeatherService;
import com.duco.api.utilities.LogManager;
import com.duco.api.utilities.RestHelper;
import com.jayway.restassured.response.Response;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class WeatherDetaislSteps extends BasePage {
	BasePage basePage=new BasePage();
	String API_NAME="WeatherReport";
	private ThreadLocal<WeatherService> weatherService=new ThreadLocal<WeatherService>()
			{
		public WeatherService initialValue()
		{
		return new WeatherService();
		}
			};
	
	//public static String uri=System.getProperty("CUSTOMER_SERVICE_"+System.getProperty("ENVIRONMENT")+"_URI");
    String URI="http://reqres.in/api/users?page=2";
	public Response result;
	public RestHelper restHelper= new RestHelper();
	public Logger logman=LogManager.getInstance();
	@Given("user Pass the Page number which required to view the details {int}")
	public void pageView(int number) {
		int pageNumber=number;
		System.out.println("page which we are getting the details ="+pageNumber);
	}

	@When("user request the service with pagenumber as {int}")
	public void userRequestTheService(int number ) {
		HashMap<String,String> weatherHeaders=weatherService.get().setDefaultHeaders();
		System.out.println("Actual EndPoint Requesting :>>>>>>>>>>>>>>>>>>>>>"+URI);
		result=restHelper.GetMesaage(URI,weatherHeaders);
		basePage.injectErrorToCucumberReport("Requested endPoint :" +URI);
		basePage.injectErrorToCucumberReport("Actual Response From Server"+result.getBody().asString());
		//System.out.println(result.getBody().asString());
		
	}

	@Then("service return the response as expected with status code")
	public void page_title_should_be() {
		
		weatherService.get().verifySuccessResponseStatusCode(result);
		basePage.injectErrorToCucumberReport("Actual Response Status code "+result.getStatusCode());
	}

}
