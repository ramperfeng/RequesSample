package com.duco.api.utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.codehaus.plexus.util.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class ReportUtils {
	
	public Logger logman;
	public ReportUtils()
	{
		logman=LogManager.getInstance();
	}
	public void invokeAspectWeaverJar(String mavenRepoPath)
	{
		try
		{
			Runtime.getRuntime().exec("java -jar"+mavenRepoPath);
			logman.info("Aspectweaver jar is invoked Successfully");
		}catch (Throwable e)
		{
			logman.error("Error in invoking Aspectweaver jar, Error = "+e.getMessage());
		}
	}
	public void createEnvironmentXmlFile()
	{
		try
		{
			DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder= documentBuilderFactory.newDocumentBuilder();
			Document document=documentBuilder.newDocument();
			//root elements
			Element rootElement=document.createElement("environment");
			document.appendChild(rootElement);
			//first child element
			Element parameter=document.createElement("parameter");
			rootElement.appendChild(parameter);
			// platform elements
			Element key=document.createElement("key");
			key.appendChild(document.createTextNode("PLATFORM"));
			parameter.appendChild(key);
			// value of platform
			Element value=document.createElement("value");
			value.appendChild(document.createTextNode(System.getProperty("PLATFORM")));
			parameter.appendChild(value);
			//second child elements
			Element parameter1=document.createElement("parameter");
			rootElement.appendChild(parameter1);
			// type elements
			Element key1=document.createElement("key");
			key1.appendChild(document.createTextNode("TYPE"));
			parameter1.appendChild(key1);
			//value of type
			Element value1=document.createElement("value");
			value1.appendChild(document.createTextNode(System.getProperty("TYPE")));
			parameter1.appendChild(value1);

			//third child
			Element parameter2=document.createElement("parameter");
			rootElement.appendChild(parameter2);
			// type elements
			Element key2=document.createElement("key");
			key2.appendChild(document.createTextNode("ENVIRONMENT"));
			parameter2.appendChild(key2);
			//value of type
			Element value2=document.createElement("value");
			value2.appendChild(document.createTextNode(System.getProperty("ENVIRONMENT")));
			parameter2.appendChild(value2);
			TransformerFactory transformerFactory=TransformerFactory.newInstance();
			Transformer transformer=transformerFactory.newTransformer();
			DOMSource source=new DOMSource(document);
			StreamResult result=new StreamResult(new File(System.getProperty("user.dir")+"/src/test/resources/allure_dependencies/environment.xml"));
			transformer.transform(source,result);
			logman.info("Environment .xml file is created successfully");


		}catch (Exception e)
		{
			logman.error("error in creating Environment.xml file ,Error="+e.getMessage());
		}
	}
	
	public void generateAllurehtmlReport()
	{
		try
		{
			if (! System.getenv("ALLURE_HOME").isEmpty())
			{
				ProcessBuilder processBuilder= new ProcessBuilder(System.getenv("ALLURE_HOME")+"/bin/allure.bat","serve",System.getProperty("user.dir")+"/target/allure-results");
				processBuilder.redirectErrorStream(true);
				Process process=processBuilder.start();
				logman.info("Allure Html Report generated Successfully");
				BufferedReader reader =new BufferedReader(new InputStreamReader(process.getInputStream()));
				String line;
				line=reader.readLine();
				while (line !=null)
				{
					System.out.println("taskList :"+ line);
					line=reader.readLine();
					if(line.contains("Server started at"))
					{
						process.destroy();
						break;
					}
				}
			}else
			{
				System.out.println("Allure is not configured in environment ");
			}
		}catch (Throwable e)
		{
			logman.error("Error in generating Allure HTML report ,Error = "+ e.getMessage());
			
		}
	}
	
	public void copyEnvironmentAndCategoriesFile()
	{
		try
		{
			FileUtils.copyFile(new File(System.getProperty("user.dir")+"/src/test/resources/allure_dependencies/environment.xml"),new File(System.getProperty("user.dir")+"/target/allure-results/environment.xml"));
			FileUtils.copyFile(new File(System.getProperty("user.dir")+"/src/test/resources/allure_dependencies/categories.json"),new File(System.getProperty("user.dir")+"/target/allure-results/categories.json"));
			
		}catch (Throwable e)
		{
			logman.error("Error in copying 'Environment .xml' and 'categories.json' file onto target folder ,Error= "+e.getMessage());
		}
	}

	public void generateAllureReport(String mavenRepoPath)
	{
		
		try
		{
			invokeAspectWeaverJar(mavenRepoPath);
			createEnvironmentXmlFile();
			copyEnvironmentAndCategoriesFile();
			generateAllurehtmlReport();
			logman.info("Allure Report generated successfully");
		}
		catch (Throwable e)
		{
			logman.error("Error in generating Allure Report , error="+e.getMessage());
		}
		
		
	}
	
}
