package com.duco.api.stepDefinations;


import com.duco.api.pageobjects.BasePage;
import com.duco.api.service.WeatherService;
import com.duco.api.utilities.Excel_Reader;
import com.duco.api.utilities.LogManager;
import com.duco.api.utilities.RestHelper;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.log4j.Logger;

import java.util.HashMap;


public class ReqresPostSteps {
	BasePage basePage=new BasePage();
	String API_NAME="ReqresPost";
	String inputPayload;
	private ThreadLocal<String> resourceReqPayload=new ThreadLocal<>();
	private ThreadLocal<WeatherService> weatherService=new ThreadLocal<WeatherService>()
			{
		public WeatherService initialValue()
		{
		return new WeatherService();
		}
			};
	
	//public static String uri=System.getProperty("CUSTOMER_SERVICE_"+System.getProperty("ENVIRONMENT")+"_URI");
	public static String uri=System.getProperty("CUSTOMER_SYSTEM_SIT_URI");

	public Response result;
	public RestHelper restHelper= new RestHelper();
	public Logger logman=LogManager.getInstance();

	@Given("user have providing valid input request payload {string} for resource creation")
	public void setupResourceCreationPayload(String payload) {
  if((payload.contains("FieldMissing"))==true)
  {
	  Excel_Reader.mandetroryorEmptyFieldValidate.set("Y");
  }
		inputPayload=Excel_Reader.readXlsJONFile(payload,API_NAME,"DATA");
		inputPayload=Excel_Reader.jsonFormat(inputPayload);
		resourceReqPayload.set(inputPayload);
		basePage.injectErrorToCucumberReport("Resource Request Payload : "+resourceReqPayload.get());
		if((payload.contains("FieldMissing"))==true)
		{
			Excel_Reader.mandetroryorEmptyFieldValidate.set("N");
		}
	}

	@When("user request Resource creation endpoint valid request Payload {string}")
	public void executePost(String payload) throws Throwable{
		String endPoint=uri+System.getProperty("RESOUCECREATION_ENDPOINT");
		HashMap<String,String> weatherHeaders=weatherService.get().setDefaultHeaders();
		System.out.println("Actual EndPoint Requesting :>>>>>>>>>>>>>>>>>>>>>"+endPoint);
		result=restHelper.PostMessageByMessageBody(endPoint,resourceReqPayload.get(),weatherHeaders);
		basePage.injectErrorToCucumberReport("Requested endPoint : " +endPoint);
		basePage.injectErrorToCucumberReport("Actual Response From Server"+result.getBody().asString());
		//System.out.println(result.getBody().asString());
		
	}

	@Then("Resource creation service return the expected success {string} as response")
	public void ResourceCreationSuccessResponse(String responsePayload) {
		weatherService.get().verifySuccessResponseStatusCodeForCreate(result);
		basePage.injectErrorToCucumberReport("Actual Response Status code "+result.getStatusCode());
		basePage.injectErrorToCucumberReport("Actual Response From Server  "+result.getBody().asString());
		//Excel_Reader.readMultipleRecordsXlsJSONFile(responsePayload,API_NAME,"RESPONSE",result.getBody().asString());

		JsonPath jsonPathEvaluator=result.jsonPath();
		String accutalvalue=jsonPathEvaluator.get();
		//outputPayload=Excel_Reader.

	}

}
