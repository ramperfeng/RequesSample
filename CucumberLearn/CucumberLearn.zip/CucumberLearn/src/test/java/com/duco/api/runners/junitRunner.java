package com.duco.api.runners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/java/com/duco/api/feature"},
		plugin= {"pretty","json:target/cucumber-parallel/cucumber.json","junit:target/cucumber-parallel/cucumber.xml"}

,dryRun=false,
		tags= "@ERPFI1",glue= {"com.duco.api"})
public class junitRunner {

}
