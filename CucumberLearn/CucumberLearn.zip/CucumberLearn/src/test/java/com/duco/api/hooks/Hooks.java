package com.duco.api.hooks;

import java.io.FileInputStream;
import java.util.Map;
import java.util.Properties;


import org.apache.log4j.Logger;

import com.duco.api.utilities.LogManager;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	
	public static Scenario testscenario;
	public static final String propFilePath="src/test/java/com/duco/api/globalconfig/GlobalConfig.properties";
	public static final String ErrorPropPath="src/test/resources/test_props/errors.properties";
	public static final String EndPointPropPath="src/test/resources/test_props/apiEndPoints.properties";
	public Logger logman;
	public Properties globalConfig;
	public FileInputStream FIS=null;
	public FileInputStream errorProps=null;
	public FileInputStream endpointProps=null;
	public Map<String,Map<String,String>> deserializeData;

	@Before
	public void init(Scenario scenario)
	{
		testscenario=scenario;
		System.setProperty("ScenarioName", scenario.getName());
		System.setProperty("ScenarioID", parseScenarioID(scenario.getId()));
		System.setProperty("propFilePath", propFilePath);
	LogManager.resetLogger();
	logman=LogManager.getInstance();
		logman.debug("Scenario name is ="+System.getProperty("ScenarioName"));
		loadGlobalConfig();
		failSafePropertyGenenration();
		
	}
	
	@After
	public void tearDown()
	{
		try
		{
			if(System.getProperty("TYPE").equalsIgnoreCase("API"))
{
				System.out.println("type is API");
	
}
		}catch (Throwable e)
		{
			logman.error("Error in tear down , message="+e.getMessage());
		}
		
	}
	
	
	public String parseScenarioID(String scenarioID)
	{
		try
		{
			String [] arr=scenarioID.split("/");
			return arr[arr.length-1].replaceAll(":", "_");
		}catch(Throwable e)
		{
			logman.error("Error in parsing please check parseScnearioId method ,error ="+e.getMessage());
		}
		return "";
	}

	
	public void loadGlobalConfig()
	{
		try
		{
			FIS=new FileInputStream(propFilePath);
			errorProps=new FileInputStream(ErrorPropPath);
			endpointProps=new FileInputStream(EndPointPropPath);
			globalConfig=new Properties();
			globalConfig.load(FIS);
			globalConfig.load(errorProps);
			globalConfig.load(endpointProps);
			logman.debug("property files are loaded successfully");
			
			
			
		}catch (Exception e)
		{
			logman.error("Error Occured Inside init block in Hooks,Error Description ="+e.getMessage());
		}
	}
	
	public void failSafePropertyGenenration()
	{
		 try
		  {
			  for (Object prop:globalConfig.keySet())
			  {
				if(System.getenv(prop.toString())!=null)
				{
					System.setProperty(prop.toString().trim().toUpperCase(),System.getenv(prop.toString()));
					logman.info(prop.toString().trim().toUpperCase()+"property is set from environment to "+System.getenv(prop.toString()));
				}else 
				{
					System.setProperty(prop.toString().trim().toUpperCase(),globalConfig.getProperty(prop.toString()));
					logman.info(prop.toString().trim().toUpperCase()+"property is set from environment to "+globalConfig.getProperty(prop.toString()));
					
				}
			  }
			  }catch (Exception e)
		  {
				  logman.error("Error Occured Inside failSafePropertyGenaeration block in preRun,Error Description ="+e.getMessage());
		  }

	}
}
