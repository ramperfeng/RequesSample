package com.duco.api.utilities;

import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class PostRunUtility {
	
	public FileInputStream FIS= null;
	public static Properties Config=null;
	public static Logger logman;
	public PostRunUtility()
	{
		try
		{
			System.setProperty("ScenarioName", "PostRunLog");
			System.setProperty("ScenarioID", "PostRunID");
			logman=LogManager.getInstance();
			FIS= new FileInputStream(System.getProperty("user.dir")+"/src/test/java/com/duco/api/globalconfig/GlobalConfig.properties");
			Config= new Properties();
			Config.load(FIS);
			failSafePropertyGeneration();
			
			
		}
		catch (Throwable e)
		{
			logman.error("unable to create postrun log ,error ="+e.getMessage());
		}
	}
	public static void main(String [] args)
	{System.out.println("Post run  utility method Lauched properly ");
		PostRunUtility postRunUtility = new PostRunUtility();
		System.out.println("path ="+System.getProperty("mavenLocalRepo"));
		ReportUtils reportUtils= new ReportUtils();
		try
		{
			postRunUtility.logMessage("Report Type= "+System.getProperty("REPORT_TYPE"));
			switch (System.getProperty("REPORT_TYPE").toUpperCase())
			
			{
			case "ALLURE":
				reportUtils.generateAllureReport(System.getProperty("mavenLocalRepo"));
				break;
			default:
				reportUtils.generateAllureReport(System.getProperty("mavenLocalRepo"));
				break;
				
			
			}
			
			
			
		}catch(Throwable e)
		{
			postRunUtility.logError("Error in generatiing Report , for Report Type= "+e.getMessage());
		}
	}
	public static void failSafePropertyGeneration()
	  {
		  
	  try
	  {
		  for (Object prop:Config.keySet())
		  {
			if(System.getenv(prop.toString())!=null)
			{
				System.setProperty(prop.toString().trim().toUpperCase(),System.getenv(prop.toString()));
			}else 
			{
				System.setProperty(prop.toString().trim().toUpperCase(),Config.getProperty(prop.toString()));
			}
		  }
		  }catch (Exception e)
	  {
			  logman.error("Error Occured Inside failSafePropertyGenaeration block in preRun,Error Description ="+e.getMessage());
	  }
			  
	  }
	public void logMessage(String message)
	{
		logman.info(message);
		System.out.println(message);
	}
	public void logError(String message)
	{
		logman.error(message);
		System.out.println(message);
	}

}
