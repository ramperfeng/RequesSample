package com.duco.api.runners;

import com.duco.api.hooks.Hooks;
import com.duco.api.pageobjects.BasePage;

public class Test extends BasePage {
	
	public static void main(String []args) throws Exception {
		Hooks hooks=new Hooks ();
		hooks.loadGlobalConfig();
		hooks.failSafePropertyGenenration();
	}

}
