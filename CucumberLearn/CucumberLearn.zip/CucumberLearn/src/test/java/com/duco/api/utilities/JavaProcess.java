package com.duco.api.utilities;

import java.io.File;

public class JavaProcess {
	
	private JavaProcess()
	{
		
	}
	public static int exec(Class klass)
	{
		System.out.println("Java Process");
		Process process= null;
		try
		{
			String javaHome=System.getProperty("java.home");
			String javaBin=javaHome+File.separator+"bin"+File.separator+"java";
			String classpath=System.getProperty("java.class.path");
			String className=klass.getCanonicalName();
			ProcessBuilder builder= new ProcessBuilder(javaBin,"-cp",classpath,className);
			process = builder.start();
			process.waitFor();
			System.out.println("exit value ="+process.exitValue());
			return process.exitValue();
		}catch (Exception e)
		{
			System.out.println("Error in javaprocess Class,Error="+e.getMessage());
		}
		
		return -1;
	}

}
